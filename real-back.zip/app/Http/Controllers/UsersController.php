<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

use App\Models\User;

class UsersController extends Controller
{
    /**
     * Handle an authentication attempt.
     *
     * @param  \Illuminate\Http\Request $request
     *
     * @return Response
     */
    public function register(Request $request)
    {
        $validator = $request->validate([
            'data.fullname' => 'required',
            'data.email' => 'required|email|unique:users,email',
            'data.password' => 'required',
        ]);
        
        $user = new User;
        $user->name = $request->input('data.fullname');
        $user->email = $request->input('data.email');
        $user->password = Hash::make($request->input('password'));
        $user->role = '1';
        if($user->save()) {
            return response()->json(['status'=>'1','message' => 'Successfully registered'], 200);
        } else {
            return response()->json(['status'=>'0','message' => 'User has not been registered'], 422);
        }
    }

    public function users() {
        $users = User::select('id', 'name', 'email')->where('role', '<>', '0')->get();
        return response()->json(['status'=>'1','message' => 'User List', 'users' => $users], 200);
    }

    public function logout(Request $request) {
        $request->user()->currentAccessToken()->delete();
        $request->user()->tokens()->delete();
        return response()->json(['status'=>'1','message' => 'Successfully Logout'], 200);
    }

}